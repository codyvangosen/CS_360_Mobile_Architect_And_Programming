package com.example.codyvangoseneventtrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Constants for the database and table
    public static final String DATABASE_NAME = "eventTracking.db";
    public static final String TABLE_USERS = "users";
    public static final String TABLE_EVENTS = "events";

    // User table columns
    public static final String COL_ID = "ID";
    public static final String COL_USERNAME = "USERNAME";
    public static final String COL_PASSWORD = "PASSWORD";

    // Event table columns
    public static final String COL_EVENT_ID = "EVENT_ID";
    public static final String COL_EVENT_NAME = "EVENT_NAME";
    public static final String COL_EVENT_DATE = "EVENT_DATE";
    public static final String COL_USER_ID = "USER_ID";  // Foreign key to associate events with users

    // Database version
    private static final int DATABASE_VERSION = 2;

    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            // Create users table
            String createUserTableSQL = "CREATE TABLE " + TABLE_USERS + " ("
                    + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COL_USERNAME + " TEXT NOT NULL, "
                    + COL_PASSWORD + " TEXT NOT NULL)";
            db.execSQL(createUserTableSQL);

            // Create events table with a foreign key to users table
            String createEventTableSQL = "CREATE TABLE " + TABLE_EVENTS + " ("
                    + COL_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COL_EVENT_NAME + " TEXT NOT NULL, "
                    + COL_EVENT_DATE + " TEXT NOT NULL, "
                    + COL_USER_ID + " INTEGER NOT NULL, "
                    + "FOREIGN KEY(" + COL_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COL_ID + "))";
            db.execSQL(createEventTableSQL);
        } catch (SQLException e) {
            Log.e("DatabaseHelper", "Error creating tables: " + e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            // Drop existing tables if they exist
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
            onCreate(db);  // Recreate the tables
        } catch (SQLException e) {
            Log.e("DatabaseHelper", "Error upgrading tables: " + e.getMessage());
        }
    }

    public boolean addUser(String username, String password) {
        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            Log.e("DatabaseHelper", "Invalid input: Username or password is empty");
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_PASSWORD, password);

        try {
            long result = db.insert(TABLE_USERS, null, contentValues);
            return result != -1;
        } catch (SQLException e) {
            Log.e("DatabaseHelper", "Error inserting user: " + e.getMessage());
            return false;
        } finally {
            db.close();
        }
    }

    /**
     * Checks if a user exists in the database and returns the user's ID if found.
     * @param username The username to check
     * @param password The password to check
     * @return The user's ID if found, -1 if the user does not exist
     */
    public int checkUser(String username, String password) {
        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            Log.e("DatabaseHelper", "Invalid input: Username or password is empty");
            return -1;
        }

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ?",
                new String[]{username, password});

        if (cursor.moveToFirst()) {
            int userId = cursor.getInt(cursor.getColumnIndex(COL_ID));
            cursor.close();
            db.close();
            return userId;
        } else {
            cursor.close();
            db.close();
            return -1;  // User not found
        }
    }

    public boolean addEvent(String eventName, String eventDate, int userId) {
        if (eventName == null || eventName.isEmpty() || eventDate == null || eventDate.isEmpty()) {
            Log.e("DatabaseHelper", "Invalid input: Event name or date is empty");
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_EVENT_NAME, eventName);
        contentValues.put(COL_EVENT_DATE, eventDate);
        contentValues.put(COL_USER_ID, userId);

        try {
            long result = db.insert(TABLE_EVENTS, null, contentValues);
            return result != -1;
        } catch (SQLException e) {
            Log.e("DatabaseHelper", "Error inserting event: " + e.getMessage());
            return false;
        } finally {
            db.close();
        }
    }

    public Cursor getUserEvents(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            return db.rawQuery("SELECT * FROM " + TABLE_EVENTS + " WHERE " + COL_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        } catch (SQLException e) {
            Log.e("DatabaseHelper", "Error retrieving events: " + e.getMessage());
            return null;
        }
    }

    public boolean deleteEvent(int eventId) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            int result = db.delete(TABLE_EVENTS, COL_EVENT_ID + "=?", new String[]{String.valueOf(eventId)});
            return result > 0;
        } catch (SQLException e) {
            Log.e("DatabaseHelper", "Error deleting event: " + e.getMessage());
            return false;
        } finally {
            db.close();
        }
    }

    public boolean updateEvent(int eventId, String newName, String newDate) {
        if (newName == null || newName.isEmpty() || newDate == null || newDate.isEmpty()) {
            Log.e("DatabaseHelper", "Invalid input: Event name or date is empty");
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_EVENT_NAME, newName);
        contentValues.put(COL_EVENT_DATE, newDate);

        try {
            int result = db.update(TABLE_EVENTS, contentValues, COL_EVENT_ID + "=?", new String[]{String.valueOf(eventId)});
            return result > 0;
        } catch (SQLException e) {
            Log.e("DatabaseHelper", "Error updating event: " + e.getMessage());
            return false;
        } finally {
            db.close();
        }
    }

    public int getLastInsertedEventId() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT last_insert_rowid()", null);
        int lastId = -1;
        if (cursor.moveToFirst()) {
            lastId = cursor.getInt(0);
        }
        cursor.close();
        return lastId;
    }
}
