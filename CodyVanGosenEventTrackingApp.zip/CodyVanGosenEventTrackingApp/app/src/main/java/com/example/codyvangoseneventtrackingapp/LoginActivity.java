package com.example.codyvangoseneventtrackingapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameField;
    private EditText passwordField;
    private Button loginButton;
    private Button createAccountButton;
    private DatabaseHelper db;  // Database helper object for database operations

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize the database helper
        db = new DatabaseHelper(this);

        // Reference XML elements for user input fields and buttons
        usernameField = findViewById(R.id.username);
        passwordField = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);
        createAccountButton = findViewById(R.id.create_account_button);

        // Set up login button with database check
        loginButton.setOnClickListener(v -> {
            String username = usernameField.getText().toString().trim();
            String password = passwordField.getText().toString().trim();

            // Input validation
            if (username.isEmpty()) {
                usernameField.setError("Username cannot be empty");
                return;
            }

            if (password.isEmpty()) {
                passwordField.setError("Password cannot be empty");
                return;
            }

            if (password.length() < 6) {
                passwordField.setError("Password must be at least 6 characters long");
                return;
            }

            // Check if user exists in the database and get the user ID
            int userId = db.checkUser(username, password);
            if (userId != -1) {
                Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();

                // Save user ID in SharedPreferences
                SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("USER_ID", userId);  // Store the user ID
                editor.apply();

                // Navigate to the next activity (EventListActivity)
                Intent intent = new Intent(LoginActivity.this, EventListActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(LoginActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        // Set up the create account button with account creation functionality
        createAccountButton.setOnClickListener(v -> {
            String username = usernameField.getText().toString().trim();
            String password = passwordField.getText().toString().trim();

            // Input validation for account creation
            if (username.isEmpty()) {
                usernameField.setError("Username cannot be empty");
                return;
            }

            if (password.isEmpty()) {
                passwordField.setError("Password cannot be empty");
                return;
            }

            if (password.length() < 6) {
                passwordField.setError("Password must be at least 6 characters long");
                return;
            }

            // Add the user to the database
            boolean isAdded = db.addUser(username, password);
            if (isAdded) {
                Toast.makeText(LoginActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(LoginActivity.this, "Account creation failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
