package com.example.codyvangoseneventtrackingapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class EventListActivity extends AppCompatActivity implements EventAdapter.OnEventClickListener {

    private RecyclerView recyclerView;
    private EventAdapter adapter;
    private List<Event> eventList;
    private DatabaseHelper dbHelper;
    private Button addEventButton;
    private int userId;  // Stores the logged-in user's ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        // Retrieve user ID from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        userId = sharedPreferences.getInt("USER_ID", -1);

        if (userId == -1) {
            Toast.makeText(this, "Error: User not found, please log in again.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
            return;
        }

        // Initialize the database helper
        dbHelper = new DatabaseHelper(this);

        // Initialize RecyclerView and set layout manager
        recyclerView = findViewById(R.id.event_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize the "Add Event" button
        addEventButton = findViewById(R.id.add_event_button);
        addEventButton.setOnClickListener(v -> openCreateEventDialog());

        // Load events from the database
        loadEventsFromDatabase();

        // Set up RecyclerView with EventAdapter
        adapter = new EventAdapter(eventList, this);
        recyclerView.setAdapter(adapter);
    }

    /**
     * Opens a dialog to create a new event.
     */
    private void openCreateEventDialog() {
        // Inflate the dialog view
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_create_event, null);

        // Set up the EditTexts for event name and date
        EditText eventNameInput = dialogView.findViewById(R.id.event_name_input);
        EditText eventDateInput = dialogView.findViewById(R.id.event_date_input);

        // Build the dialog
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        builder.setView(dialogView);
        builder.setTitle("Create Event");

        // Set up dialog buttons
        builder.setPositiveButton("Create", (dialog, which) -> {
            String eventName = eventNameInput.getText().toString().trim();
            String eventDate = eventDateInput.getText().toString().trim();

            // Validate input
            if (eventName.isEmpty()) {
                Toast.makeText(EventListActivity.this, "Event name cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }
            if (eventDate.isEmpty()) {
                Toast.makeText(EventListActivity.this, "Event date cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            // Add event to the database
            boolean isAdded = dbHelper.addEvent(eventName, eventDate, userId);
            if (isAdded) {
                // Dynamically update the event list and adapter
                loadEventsFromDatabase();
                adapter.notifyItemInserted(eventList.size() - 1);
                Toast.makeText(EventListActivity.this, "Event created successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(EventListActivity.this, "Error creating event", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        // Show the dialog
        builder.create().show();
    }

    /**
     * Loads events from the database and updates the event list.
     */
    private void loadEventsFromDatabase() {
        eventList = new ArrayList<>();
        Cursor cursor = dbHelper.getUserEvents(userId);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndex("EVENT_NAME"));
                String date = cursor.getString(cursor.getColumnIndex("EVENT_DATE"));
                int id = cursor.getInt(cursor.getColumnIndex("EVENT_ID"));
                eventList.add(new Event(id, name, date));
            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }
    }

    /**
     * Handles editing an event.
     */
    @Override
    public void onEditClick(int position) {
        Event event = eventList.get(position);
        openEditEventDialog(event, position);
    }

    /**
     * Handles deleting an event.
     */
    @Override
    public void onDeleteClick(int position) {
        Event event = eventList.get(position);
        boolean isDeleted = dbHelper.deleteEvent(event.getId());
        if (isDeleted) {
            eventList.remove(position);
            adapter.notifyItemRemoved(position);
            Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error deleting event", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Opens a dialog to edit an existing event.
     */
    private void openEditEventDialog(Event event, int position) {
        // Inflate the dialog view
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_create_event, null);

        // Set up the EditTexts with current event details
        EditText eventNameInput = dialogView.findViewById(R.id.event_name_input);
        EditText eventDateInput = dialogView.findViewById(R.id.event_date_input);
        eventNameInput.setText(event.getName());
        eventDateInput.setText(event.getDate());

        // Build the dialog
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        builder.setView(dialogView);
        builder.setTitle("Edit Event");

        // Set up dialog buttons
        builder.setPositiveButton("Update", (dialog, which) -> {
            String newName = eventNameInput.getText().toString().trim();
            String newDate = eventDateInput.getText().toString().trim();

            // Validate input
            if (newName.isEmpty()) {
                Toast.makeText(EventListActivity.this, "Event name cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }
            if (newDate.isEmpty()) {
                Toast.makeText(EventListActivity.this, "Event date cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            // Update event in the database
            boolean isUpdated = dbHelper.updateEvent(event.getId(), newName, newDate);
            if (isUpdated) {
                // Dynamically update the event list and adapter
                event.setName(newName);
                event.setDate(newDate);
                adapter.notifyItemChanged(position);
                Toast.makeText(EventListActivity.this, "Event updated successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(EventListActivity.this, "Error updating event", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        // Show the dialog
        builder.create().show();
    }
}
